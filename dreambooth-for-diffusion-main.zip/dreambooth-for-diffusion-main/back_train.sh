# 省钱训练：训练正常完成后关机
sh train_style.sh && shutdown